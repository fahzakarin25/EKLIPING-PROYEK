<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/** @var yii\web\View $this */
/** @var backend\models\Media $model */

$this->title = $model->id_media;
$this->params['breadcrumbs'][] = ['label' => 'Media', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="media-view">

    <!-- <h1>?= Html::encode($this->title) ?></h1> -->

    <!-- <p>
        ?= Html::a('Update', ['update', 'id_media' => $model->id_media], ['class' => 'btn btn-primary']) ?>
        ?= Html::a('Delete', ['delete', 'id_media' => $model->id_media], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p> -->

    <div class="row">
        <div class="col-md-12">
            <div class="box box-success box-solid">
                <div class="box-header with-border">
                    <h3 class="box-title"><?= $model->nama_media ?></h3>
                    <div class="box-tools pull-right">
                    <?= Html::a('Update', ['update', 'id_media' => $model->id_media], ['class' => 'btn btn-primary']) ?>
                    <?= Html::a('Delete', ['delete', 'id_media' => $model->id_media], [
                        'class' => 'btn btn-danger',
                        'data' => [
                            'confirm' => 'Are you sure you want to delete this item?',
                            'method' => 'post',
                        ],
                    ]) ?>
                    </div>
                </div>
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="box">
                                <div class="box-body no-padding">
                                    <table class="table table-striped">
                                        <tbody>
                                            <tr>
                                                <!-- <td>1.</td> -->
                                                <td>ID Media</td>
                                                <td>
                                                    <?php 
                                                        $media= $model->id_media;
                                                        echo $media;
                                                    ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <!-- <td>1.</td> -->
                                                <td>Nama Media</td>
                                                <td>
                                                    <?php 
                                                        $nama= $model->nama_media;
                                                        echo $nama;
                                                    ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <!-- <td>1.</td> -->
                                                <td>Jenis Media</td>
                                                <td>
                                                    <?php 
                                                        $jenis= $model->jenis_media;
                                                        echo $jenis;
                                                    ?>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id_media',
            'nama_media',
            'jenis_media',
        ],
    ]) ?> -->

</div>
