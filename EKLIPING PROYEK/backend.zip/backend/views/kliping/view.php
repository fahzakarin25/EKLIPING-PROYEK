<?php

use yii\base\Model;
use yii\helpers\Html;
use yii\widgets\DetailView;


/** @var yii\web\View $this */
/** @var backend\models\Kliping $model */

// $this->title = $model->id_kliping;
$this->title = $model->judul;
$this->params['breadcrumbs'][] = ['label' => 'Kliping', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="kliping-view">

    <!-- <h1>?= Html::encode($this->title) ?></h1> -->

    <p>
        <!-- ?= Html::a('Update', ['update', 'id_kliping' => $model->id_kliping], ['class' => 'btn btn-primary']) ?>
        ?= Html::a('Delete', ['delete', 'id_kliping' => $model->id_kliping], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?> -->
    </p>

    <div class="row">
        <div class="col-md-12">
            <div class="box box-success box-solid">
                <div class="box-header with-border">
                    <h3 class="box-title">Judul : <?= $model->judul ?></h3>
                    <div class="box-tools pull-right">
                        <?= Html::a('<i class="fa fa-undo" aria-hidden="true"></i> Update', ['update', 'id_kliping' => $model->id_kliping], ['class' => 'btn btn-primary']) ?>
                        <?= Html::a('<i class="fa fa-trash" aria-hidden="true"></i> Delete', ['delete', 'id_kliping' => $model->id_kliping], [
                            'class' => 'btn btn-danger',
                            'data' => [
                                'confirm' => 'Are you sure you want to delete this item?',
                                'method' => 'post',
                            ],
                        ]) ?>
                        <?= Html::a('<i class="fa fa-print" aria-hidden="true"></i> Print', ['cetak-kliping', 'id_kliping' => $model->id_kliping], ['class' => 'btn btn-warning']) ?>
                    </div>
                </div>
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="box">
                                <div class="box-body no-padding">
                                    <table class="table table-striped">
                                        <tbody>
                                            <tr>
                                                <!-- <th style="width: 10px">#</th> -->
                                                <!-- <th>Task</th>
                                                <th>Progress</th> -->
                                                <!-- <th style="width: 40px">Label</th> -->
                                            </tr>
                                            <tr>
                                                <!-- <td>1.</td> -->
                                                <td>Tanggal</td>
                                                <td>
                                                    <?php
                                                    $tanggal = $model->tanggal;
                                                    $tanggal_indo = $model->tglIndo($tanggal);
                                                    echo $tanggal_indo;
                                                    ?>
                                                    <!-- ?= $model->tanggal?> -->
                                                    <!-- <div class="progress progress-xs">
                                                        <div class="progress-bar progress-bar-danger" style="width: 55%"></div>
                                                    </div> -->
                                                </td>
                                                <!-- <td><span class="badge bg-red">55%</span></td> -->
                                            </tr>
                                            <tr>
                                                <!-- <td>2.</td> -->
                                                <td>Kategori</td>
                                                <td>
                                                    <?php
                                                    $kategori = $model->jenisKategori->jenis_kategori;
                                                    echo $kategori;
                                                    ?>
                                                    <!-- <div class="progress progress-xs">
                                                        <div class="progress-bar progress-bar-yellow" style="width: 70%"></div>
                                                    </div> -->
                                                </td>
                                                <!-- <td><span class="badge bg-yellow">70%</span></td> -->
                                            </tr>
                                            <tr>
                                                <!-- <td>3.</td> -->
                                                <td>Media</td>
                                                <td>
                                                    <?php
                                                    $media = $model->namaMedia->nama_media;
                                                    echo $media;
                                                    ?>
                                                    <!-- <div class="progress progress-xs progress-striped active">
                                                        <div class="progress-bar progress-bar-primary" style="width: 30%"></div>
                                                    </div> -->
                                                </td>
                                                <!-- <td><span class="badge bg-light-blue">30%</span></td> -->
                                            </tr>
                                            <tr>
                                                <!-- <td>4.</td> -->
                                                <td>Jurnalis</td>
                                                <td>
                                                    <?php
                                                    $jurnalis = $model->namaJurnalis->nama_jurnalis;
                                                    echo $jurnalis;
                                                    ?>
                                                    <!-- <div class="progress progress-xs progress-striped active">
                                                        <div class="progress-bar progress-bar-success" style="width: 90%"></div>
                                                    </div> -->
                                                </td>
                                                <!-- <td><span class="badge bg-green">90%</span></td> -->
                                            </tr>
                                            <tr>
                                                <!-- <td>5.</td> -->
                                                <td>Status Public</td>
                                                <td>
                                                    <?php
                                                    $stat = $model->status_publis;
                                                    if ($stat == 1) {
                                                        $status = '<span class="label label-success">Publish</span>';
                                                    } elseif ($stat == 2) {
                                                        $status = '<span class="label label-danger">Tidak Publish</span>';
                                                    } else {
                                                        $status = '';
                                                    }

                                                    echo $status;
                                                    ?>
                                                    <!-- ?= $model->status_publis?> -->
                                                    <!-- <div class="progress progress-xs progress-striped active">
                                                        <div class="progress-bar progress-bar-success" style="width: 90%"></div>
                                                    </div> -->
                                                </td>
                                                <!-- <td><span class="badge bg-green">90%</span></td> -->
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <?php
                            $root_folder = Yii::getAlias('@root');
                            $gambar = Html::img($root_folder . $model->lokasi_upload, ['class' => 'img-responsive']);

                            echo $gambar;
                            ?>
                        </div>
                        <!-- <div class="col-md-6"> -->
                        <!-- ?php 
                                $upload = $model->lokasi_upload;
                                echo $upload;
                            ?> -->
                        <!-- ?php
                                $root_folder=Yii::getAlias('@root');
                                echo Html::img($root_folder.$model->lokasi_upload,['class' => 'img-responsive']);
                            ?> -->
                        <!-- </div> -->
                    </div>
                </div>

                <!-- <div class="box-body"> KODINGAN DARI KAK SUCI CUMAN BATAL 
                    <div class="row">
                        <div class="col-sm-6">
                            <table class="table table-striped">
                                <tbody>
                                    <tr>
                                        <td>Tanggal</td>
                                        <td>
                                            ?php
                                                $tgl_kliping = $model->tanggal;
                                                $tanggal_indo = $model->tglIndo($tgl_kliping);
                                                return $tanggal_indo;
                                            ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Kategori</td>
                                        <td>?=  $model->jenisKategori ? $model->jenisKategori->jenis_kategori : '-'; ?></td>
                                    </tr>
                                    <tr>
                                        <td>Jurnalis</td>
                                        <td>?= $model->namaJurnalis ? $model->namaJurnalis->nama_jurnalis : '-'; ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="col-sm-6">
                            ?php
                                $root_folder = Yii::getAlias('@root');
                                $gambar = Html::img($root_folder.$model->lokasi_upload,['class'=>'img-responsive']);
                                echo $gambar;
                            ?>
                        </div>
                    </div>
                </div> -->
            </div>
        </div>
    </div>

    <!-- <div class="row"> INI AWAL BANGET YANG BAGUS JUGA TAMPILAN NYA
        <div class="col-md-12">
            <div class="box box-success " style="padding-top: 15px;">
                <div class="row">
                    <div class="col-md-9">
                        <div class="box-header with-border">
                            <h3 class="box-title">Tampilan Data Kliping</h3>
                        </div>
                    </div>
                    <div class="col-md-3" style="padding-left: 120px; padding: bottom 5px;" >
                            ?= Html::a('Update', ['update', 'id_kliping' => $model->id_kliping], ['class' => 'btn btn-primary']) ?>
                            ?= Html::a('Delete', ['delete', 'id_kliping' => $model->id_kliping], [
                                'class' => 'btn btn-danger',
                                'data' => [
                                    'confirm' => 'Are you sure you want to delete this item?',
                                    'method' => 'post',
                                ],
                            ]) ?>
                    </div>
                </div>
                <div class="box-body">
                    <div class="col-md-7">
                        ?= DetailView::widget([
                            'model' => $model,
                            'attributes' => [
                                // 'id_kliping',
                                'judul',
                                // 'tanggal',
                                [
                                    'attribute' => 'tanggal',
                                    'label'=>'Tanggal',
                                    'format' =>'raw',
                                    'value'=>function($model){
                                        $tgl_kliping = $model->tanggal;
                                        $tanggal_indo = $model->tglIndo($tgl_kliping);
                                        return $tanggal_indo;
                                    }
                                ],
                                // 'kategori',
                                [
                                    'attribute' => 'kategori',
                                    'label'=>'Kategori Kliping',
                                    'value'=>function($model){
                                        return $model->jenisKategori ? $model->jenisKategori->jenis_kategori : '-';
                                    }
                                ],
                                'media',
                                // 'jurnalis',
                                [
                                    'attribute' => 'jurnalis',
                                    'label'=>'Jurnalis',
                                    'value'=>function($model){
                                        return $model->namaJurnalis ? $model->namaJurnalis->nama_jurnalis : '-';
                                    }
                                ],
                                // 'lokasi_upload',
                                'status_publis',
                                // 'create_time',
                                // 'update_time',
                                // 'create_by',
                                // 'update_by',
                            ],
                        ]) ?>
                    </div>
                    <div class="col-md-5">
                        <div class="box-body">
                            ?= DetailView::widget([
                                'model' => $model,
                                'attributes' => [
                                    'lokasi_upload',
                                    // $root_folder = Yii::getAlias('@root');
                                    // $gambar = Html::img($root_folder.$model->lokasi_upload,['class'=>'img-responsive']);

                                    // echo $gambar;
                                ],
                            ]) ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->

</div>