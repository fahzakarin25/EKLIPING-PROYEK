<?php
        $roleName = Yii::$app->user->identity->role->name;//untuk mendapatkan role name
        echo $roleName; 

        if(Yii::$app->user->isGuest==false && $roleName=='Admin'){
            $menu = [
                [
                    'label' => 'Dashboard',
                    'url' => ['/site'], "icon" => "dashboard"
                ],
                [
                    'label' => 'Data Kliping',
                    'url' => ['/kliping'], "icon" => "fa-fw fa-clone"
                ],
                [
                    'label' => 'Kategori Kliping',
                    'url' =>  ['/kategori-kliping'], "icon" => "fa-fw fa-th-list"
                ],
                [
                    'label' => 'Data Jurnalis',
                    'url' => ['/jurnalis'], "icon" => "fa-fw fa-users"
                ],
                [
                    'label' => 'Data Media',
                    'url' => ['/media'], "icon" => "fa-fw fa-newspaper-o"
                ],
                [
                    'label' => 'Profile User',
                    'url' => ['/user/profile'], "icon" => "fa-fw fa-user"
                ],
                [
                    'label' => 'User Admin',
                    'url' => ['/user/admin'], "icon" => "fa-fw fa-user"
                ],
            ];
        }
        elseif(Yii::$app->user->isGuest==false && $roleName=='Jurnalis'){
            $menu = [
                [
                    'label' => 'Beranda',
                    'url' => ['/site/index-jurnalis'], "icon" => "fa-fw fa-users"
                ],
            ];
        }
        ?>
        <?= dmstr\widgets\Menu::widget([
            "items" => $menu
        ]) ?>

<?= dmstr\widgets\Menu::widget(
            [
                'options' => ['class' => 'sidebar-menu tree', 'data-widget'=> 'tree',],
                'items' => [
                    // ['label' => 'Menu Yii2', 'options' => ['class' => 'header']],
                    // ['label' => 'Gii', 'icon' => 'file-code-o', 'url' => ['/gii']],
                    // ['label' => 'Debug', 'icon' => 'dashboard', 'url' => ['/debug']],
                    ['label' => 'Dashboard', 'icon' => 'dashboard', 'url' => ['/site']],
                    // ['label' => 'Login', 'url' => ['site/login'], 'visible' => Yii::$app->user->isGuest],
                    // [
                    //     'label' => 'Some tools',
                    //     'icon' => 'share',
                    //     'url' => '#',
                    //     'items' => [
                    //         ['label' => 'Gii', 'icon' => 'file-code-o', 'url' => ['/gii'],],
                    //         ['label' => 'Debug', 'icon' => 'dashboard', 'url' => ['/debug'],],
                    //         [
                    //             'label' => 'Level One',
                    //             'icon' => 'circle-o',
                    //             'url' => '#',
                    //             'items' => [
                    //                 ['label' => 'Level Two', 'icon' => 'circle-o', 'url' => '#',],
                    //                 [
                    //                     'label' => 'Level Two',
                    //                     'icon' => 'circle-o',
                    //                     'url' => '#',
                    //                     'items' => [
                    //                         ['label' => 'Level Three', 'icon' => 'circle-o', 'url' => '#',],
                    //                         ['label' => 'Level Three', 'icon' => 'circle-o', 'url' => '#',],
                    //                     ],
                    //                 ],
                    //             ],
                    //         ],
                    //     ],
                    // ],
                    ['label' => 'Data Kliping', 'icon' => 'fa-fw fa-clone','url' => ['/kliping'],],
                    ['label' => 'Kategori Kliping', 'icon' => 'fa-fw fa-th-list', 'url' => ['/kategori-kliping']],
                    ['label' => 'Data Jurnalis', 'icon' => 'fa-fw fa-users', 'url' => ['/jurnalis']],
                    ['label' => 'Data Media', 'icon' => 'fa-fw fa-newspaper-o', 'url' => ['/media']],
                    ['label' => 'Profile User', 'icon' => 'fa-fw fa-user', 'url' => ['/user/profile']],
                    ['label' => 'User Admin', 'icon' => 'fa-fw fa-user', 'url' => ['/user/admin']],
                ],
            ]
        ) ?>

        
<?php
        $roleName = Yii::$app->user->isGuest== false ? Yii::$app->user->identity->role->name: '';//untuk mendapatkan role name
        

        if  (Yii::$app->user->isGuest==false && $roleName=='Admin'){
            $menu = [
                [
                    'label' => 'Dashboard',
                    'url' => ['/site'], "icon" => "dashboard",
                ],
                [
                    'label' => 'Data Kliping',
                    'url' => ['/kliping'], "icon" => "fa-fw fa-clone",
                ],
                [
                    'label' => 'Kategori Kliping',
                    'url' =>  ['/kategori-kliping'], "icon" => "fa-fw fa-th-list"
                ],
                [
                    'label' => 'Data Jurnalis',
                    'url' => ['/jurnalis'], "icon" => "fa-fw fa-users",
                ],
                [
                    'label' => 'Data Media',
                    'url' => ['/media'], "icon" => "fa-fw fa-newspaper-o",
                ],
                [
                    'label' => 'Profile User',
                    'url' => ['/user/profile'], "icon" => "fa-fw fa-user"
                ],
                [
                    'label' => 'User Admin',
                    'url' => ['/user/admin'], "icon" => "fa-fw fa-user",
                ],
            ];
        }
        elseif(Yii::$app->user->isGuest==false && $roleName=='Jurnalis'){
            $menu = [
                [
                    'label' => 'Beranda',
                    'url' => ['/site/indexjurnalis'], "icon" => "fa-fw fa-users"
                ],
            ];
        }
        else{
            $menu=[];
        }
        ?>
        <?=  dmstr\widgets\Menu::widget([
            "items" =>  $menu
        ]) ?>