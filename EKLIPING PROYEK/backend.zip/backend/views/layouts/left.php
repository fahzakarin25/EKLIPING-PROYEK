<aside class="main-sidebar">

    <section class="sidebar">

        <!-- Sidebar user panel -->
        <!-- <div class="user-panel" style="background-color:pink"> jadi pink warna-->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="<?= $directoryAsset ?>/img/user2-160x160.jpg" class="img-circle" alt="User Image"/>
            </div>
            <!-- <div class="pull-left info" style="color:aliceblue"> biar ganti warna  -->
            <div class="pull-left info">
                <!-- <p>Fahza Syafira Karin</p> -->
                <p><?= $roleName = Yii::$app->user->isGuest== false ? Yii::$app->user->identity->role->name: ''; ?></p>

                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>

        <!-- search form -->
        <!-- <form action="#" method="get" class="sidebar-form">
            <div class="input-group">
                <input type="text" name="q" class="form-control" placeholder="Search..."/>
                <span class="input-group-btn">
                    <button type='submit' name='search' id='search-btn' class="btn btn-flat"><i class="fa fa-search"></i>
                    </button>
                </span>
            </div>
        </form> -->
        <!-- /.search form -->

        <?php
        $roleName = Yii::$app->user->isGuest== false ? Yii::$app->user->identity->role->name: '';//untuk mendapatkan role name

        if  (Yii::$app->user->isGuest==false && $roleName=='Admin'){
            $menu = [
                [
                    'label' => 'Dashboard',
                    'url' => ['/site'], "icon" => "dashboard",
                ],
                [
                    'label' => 'Data Kliping',
                    'url' => ['/kliping'], "icon" => "fa-fw fa-clone",
                ],
                [
                    'label' => 'Kategori Kliping',
                    'url' =>  ['/kategori-kliping'], "icon" => "fa-fw fa-th-list"
                ],
                [
                    'label' => 'Data Jurnalis',
                    'url' => ['/jurnalis'], "icon" => "fa-fw fa-users",
                ],
                [
                    'label' => 'Data Media',
                    'url' => ['/media'], "icon" => "fa-fw fa-newspaper-o",
                ],
                [
                    'label' => 'Profile User',
                    'url' => ['/user/profile'], "icon" => "fa-fw fa-user"
                ],
                [
                    'label' => 'User Admin',
                    'url' => ['/user/admin'], "icon" => "fa-fw fa-user",
                ],
            ];
        }
        elseif (Yii::$app->user->isGuest==false && $roleName=='Jurnalis'){
            $menu = [
                [
                    'label' => 'Dashboard',
                    'url' => ['/site/index-jurnalis'], "icon" => "dashboard",
                ],
                [
                    'label' => 'Berita Jurnalis',
                    'url' => ['/berita-jurnalis'], "icon" => "fa-fw fa-clone",
                ],
            ];
        }
        else {
            $menu=[];
        }
        ?>

        <?=  dmstr\widgets\Menu::widget([
            "items" =>  $menu
        ]) ?>

    </section>

</aside>
