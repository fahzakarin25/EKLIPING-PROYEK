<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "media".
 *
 * @property int $id_media
 * @property string $nama_media
 * @property string $jenis_media
 */
class Media extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'media';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['nama_media', 'jenis_media'], 'required'],
            [['nama_media'], 'string', 'max' => 50],
            [['jenis_media'], 'string', 'max' => 10],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_media' => 'Id Media',
            'nama_media' => 'Nama Media',
            'jenis_media' => 'Jenis Media',
        ];
    }
    public function getDataMedia(){
        $data = Media::find()-> all();
        $dropDown = \yii\helpers\ArrayHelper::map($data,'id_media','nama_media');

        return $dropDown;
    }
}
