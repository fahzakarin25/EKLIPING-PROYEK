<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "kliping".
 *
 * @property int $id_kliping
 * @property string $judul
 * @property string $tanggal
 * @property int $kategori
 * @property string $media
 * @property string $jurnalis
 * @property string $lokasi_upload
 * @property int $status_publis
 * @property string $create_time
 * @property string $update_time
 * @property int $create_by
 * @property int $update_by
 */
class Kliping extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'kliping';
    }

    /**
     * {@inheritdoc}
     */
    public $upload_file;
    public function rules()
    {
        return [
            [['judul', 'tanggal', 'kategori', 'media', 'jurnalis', 'lokasi_upload', 'status_publis'], 'required'],
            [['id_kliping', 'kategori', 'status_publis', 'create_by', 'update_by'], 'integer'],
            [['tanggal', 'create_time', 'update_time'], 'safe'],
            [['judul', 'lokasi_upload'], 'string', 'max' => 255],
            [['media', 'jurnalis'], 'string', 'max' => 100],
            [['id_kliping'], 'unique'],

            [['upload_file',], 'required', 'on' => ['create']], // ini wajib diisi saat create
            [
                'upload_file', 'file', 'extensions' => ['jpg', 'png', 'JPEG', 'JPG'], // ini extensi gambar yang kita izinkan untuk di upload
                //'maxSize' => 1024 * 1024 * 4,
                //'tooBig' => 'Gambar cover tidak boleh lebih dari 4 mb',
                'wrongExtension' => 'Hanya format file {extensions} yang diizinkan untuk {attribute}.', //ini pesan yang muncul sat upload tidak sesuai tipe gambar
            ]
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_kliping' => 'Id Kliping',
            'judul' => 'Judul',
            'tanggal' => 'Tanggal',
            'kategori' => 'Kategori',
            'media' => 'Media',
            'jurnalis' => 'Jurnalis',
            'lokasi_upload' => 'Lokasi Upload',
            'status_publis' => 'Status Publis',
            'create_time' => 'Create Time',
            'update_time' => 'Update Time',
            'create_by' => 'Create By',
            'update_by' => 'Update By',
        ];
    }
    public function getJenisKategori()
    { //kategori
        return $this->hasOne(KategoriKliping::className(), ['id_kategori' => 'kategori']);
    }
    public function getNamaJurnalis()
    {
        return $this->hasOne(Jurnalis::className(), ['id_pers' => 'jurnalis']);
    }
    public function tglIndo($tanggal)
    {
        $bulan = array(
            1 => 'Januari',
            'Februari',
            'Maret',
            'April',
            'Mei',
            'Juni',
            'Juli',
            'Agustus',
            'September',
            'Oktober',
            'November',
            'Desember',
        );

        $pecahkan = explode('-', $tanggal);
        return $pecahkan[2] . ' ' . $bulan[(int)$pecahkan[1]] . ' ' . $pecahkan[0];
    }
    public function getNamaMedia()
    {
        return $this->hasOne(Media::className(), ['id_media' => 'media']);
    }
}
